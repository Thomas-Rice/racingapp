﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public class Bet
    {

        public int Amount = 0;
        public int Dog;
        int newAmount = 0;
        public Guy Bettor;

        public string GetDescription()
        {
            if(Amount >= 1)
            {
                return(this.Bettor.Name + " bets " + Amount + " on dog " + Dog);
            }
            else
            {
                return(this.Bettor.Name + " hasn't placed a bet");
            }

        }

        public string GetDescription(int newAmount)
        {
            if (newAmount >= 1)
            {
                return (this.Bettor.Name + " bets " + newAmount + " on dog " + Dog);
            }
            else
            {
                return (this.Bettor.Name + " hasn't placed a bet");
            }

        }

        public string changeLabelAmount(int tempAmount)
        {
            newAmount = Amount + tempAmount;
            return GetDescription(newAmount); ;
        }


        public string changeLabelDog(int dogChosen)
        {
            Dog = dogChosen;
            return GetDescription(newAmount); 
        }



        public int PayOut(int Winner)
        {
            if (Winner == Dog)
            {
                return Amount * 2;
            }
            else
            {
                return Amount * -1;
            }
        }
    }
}
