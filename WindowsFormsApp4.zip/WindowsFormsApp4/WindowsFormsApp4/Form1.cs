﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {

        GreyHound[] greyHoundArray = new GreyHound[4];
        Guy[] guyArray = new Guy[3];
        Random MyRandomizer = new Random();

        public Form1()
        {
            InitializeComponent();

            string[] names = { "Joe", "Bob", "Al" };
            Label[] betLabels = { labelTotal1, labelTotal2, labelTotal3 };
            Label[] currentLabels = { bettorsCurrentBet1, bettorsCurrentBet2, bettorsCurrentBet3 };
            comboBox1.Items.AddRange(names);
            comboBox1.SelectedIndex = 0;

            PictureBox[] dogs = { Dog1, Dog2, Dog3, Dog4 };

            //Instantiate the dogs!
            for (int i = 0; i < greyHoundArray.Length; i++)
            {
                greyHoundArray[i] = new GreyHound()
                {
                    myPictureBox = dogs[i],
                    raceTrackLength = raceTrackPictureBox.Width - raceTrackPictureBox.Width,
                    Randomizer = MyRandomizer
                };
            }



            //Instantiate the guys!
            for (int i = 0; i < guyArray.Length; i++)
            {

                guyArray[i] = new Guy()
                {
                    Name = names[i],
                    Cash = 100,
                    MyLabelTotal = betLabels[i],
                    MyLabel = currentLabels[i],
                };
            }



            //TEMP set bets
            guyArray[0].MyBet = new Bet()
            {
                Amount = 0,
                Dog = 1,
                Bettor = guyArray[0]
            };

            guyArray[1].MyBet = new Bet()
            {
                Amount = 150,
                Dog = 3,
                Bettor = guyArray[1]
            };

            guyArray[2].MyBet = new Bet()
            {
                Amount = 250,
                Dog = 4,
                Bettor = guyArray[2]
            };

            // Update the starting labels
            for (int i = 0; i < guyArray.Length; i++)
            {
                guyArray[i].UpdateLabels();
            }



        }   





   


        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Stop();
            }
            else
            {
                timer1.Start();
                
            }
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            foreach (GreyHound greyhound in greyHoundArray)
            {
                if (greyhound.Run())
                {
                    timer1.Stop();
                    MessageBox.Show("Winner " + greyhound.myPictureBox.Name);
                }
            }
        }

        private void minimumBetLabel_Click(object sender, EventArgs e)
        {

        }

        private void placeBetsButton_Click(object sender, EventArgs e)
        {
            int bettorName = comboBox1.SelectedIndex;


        }

        private void ButtonBet5_Click(object sender, EventArgs e)
        {
            int bettorName = comboBox1.SelectedIndex;
            guyArray[bettorName].changeBetAmount(5);


        }

        private void ButtonBet10_Click(object sender, EventArgs e)
        {
            int bettorName = comboBox1.SelectedIndex;
            guyArray[bettorName].changeBetAmount(10);
        }

        private void ButtonBet50_Click(object sender, EventArgs e)
        {
            int bettorName = comboBox1.SelectedIndex;
            guyArray[bettorName].changeBetAmount(50);
        }

        private void radioButtonDog1_CheckedChanged(object sender, EventArgs e)
        {
            int bettorName = comboBox1.SelectedIndex;
            guyArray[bettorName].changeDog(1);
        }

        private void radioButtonDog3_CheckedChanged(object sender, EventArgs e)
        {
            int bettorName = comboBox1.SelectedIndex;
            guyArray[bettorName].changeDog(3);
        }

        private void radioButtonDog2_CheckedChanged(object sender, EventArgs e)
        {
            int bettorName = comboBox1.SelectedIndex;
            guyArray[bettorName].changeDog(2);
        }

        private void radioButtonDog4_CheckedChanged(object sender, EventArgs e)
        {
            int bettorName = comboBox1.SelectedIndex;
            guyArray[bettorName].changeDog(4);
        }
    }



}
