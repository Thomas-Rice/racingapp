﻿namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.raceTrackPictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.minimumBetLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.StartButton = new System.Windows.Forms.Button();
            this.Dog1 = new System.Windows.Forms.PictureBox();
            this.Dog2 = new System.Windows.Forms.PictureBox();
            this.Dog3 = new System.Windows.Forms.PictureBox();
            this.Dog4 = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelTotal1 = new System.Windows.Forms.Label();
            this.labelTotal2 = new System.Windows.Forms.Label();
            this.labelTotal3 = new System.Windows.Forms.Label();
            this.ButtonBet5 = new System.Windows.Forms.Button();
            this.ButtonBet10 = new System.Windows.Forms.Button();
            this.ButtonBet50 = new System.Windows.Forms.Button();
            this.radioButtonDog1 = new System.Windows.Forms.RadioButton();
            this.radioButtonDog3 = new System.Windows.Forms.RadioButton();
            this.radioButtonDog2 = new System.Windows.Forms.RadioButton();
            this.radioButtonDog4 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.bettorsCurrentBet1 = new System.Windows.Forms.Label();
            this.bettorsCurrentBet2 = new System.Windows.Forms.Label();
            this.bettorsCurrentBet3 = new System.Windows.Forms.Label();
            this.placeBetsButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.raceTrackPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dog1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dog2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dog3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dog4)).BeginInit();
            this.SuspendLayout();
            // 
            // raceTrackPictureBox
            // 
            this.raceTrackPictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("raceTrackPictureBox.BackgroundImage")));
            this.raceTrackPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.raceTrackPictureBox.Location = new System.Drawing.Point(1, 1);
            this.raceTrackPictureBox.Name = "raceTrackPictureBox";
            this.raceTrackPictureBox.Size = new System.Drawing.Size(1313, 275);
            this.raceTrackPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.raceTrackPictureBox.TabIndex = 0;
            this.raceTrackPictureBox.TabStop = false;
            this.raceTrackPictureBox.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 282);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Betting Parlor";
            // 
            // minimumBetLabel
            // 
            this.minimumBetLabel.AutoSize = true;
            this.minimumBetLabel.Location = new System.Drawing.Point(99, 302);
            this.minimumBetLabel.Name = "minimumBetLabel";
            this.minimumBetLabel.Size = new System.Drawing.Size(73, 13);
            this.minimumBetLabel.TabIndex = 2;
            this.minimumBetLabel.Text = "Bettor\'s Name";
            this.minimumBetLabel.Click += new System.EventHandler(this.minimumBetLabel_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(422, 282);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Current Bets";
            // 
            // StartButton
            // 
            this.StartButton.Location = new System.Drawing.Point(689, 328);
            this.StartButton.Name = "StartButton";
            this.StartButton.Size = new System.Drawing.Size(203, 115);
            this.StartButton.TabIndex = 10;
            this.StartButton.Text = "Start the Race!";
            this.StartButton.UseVisualStyleBackColor = true;
            this.StartButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // Dog1
            // 
            this.Dog1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Dog1.BackgroundImage")));
            this.Dog1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Dog1.Location = new System.Drawing.Point(45, 1);
            this.Dog1.Name = "Dog1";
            this.Dog1.Size = new System.Drawing.Size(100, 50);
            this.Dog1.TabIndex = 16;
            this.Dog1.TabStop = false;
            // 
            // Dog2
            // 
            this.Dog2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Dog2.BackgroundImage")));
            this.Dog2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Dog2.Location = new System.Drawing.Point(45, 68);
            this.Dog2.Name = "Dog2";
            this.Dog2.Size = new System.Drawing.Size(100, 50);
            this.Dog2.TabIndex = 17;
            this.Dog2.TabStop = false;
            // 
            // Dog3
            // 
            this.Dog3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Dog3.BackgroundImage")));
            this.Dog3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Dog3.Location = new System.Drawing.Point(45, 144);
            this.Dog3.Name = "Dog3";
            this.Dog3.Size = new System.Drawing.Size(100, 50);
            this.Dog3.TabIndex = 18;
            this.Dog3.TabStop = false;
            // 
            // Dog4
            // 
            this.Dog4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Dog4.BackgroundImage")));
            this.Dog4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Dog4.Location = new System.Drawing.Point(45, 214);
            this.Dog4.Name = "Dog4";
            this.Dog4.Size = new System.Drawing.Size(100, 50);
            this.Dog4.TabIndex = 19;
            this.Dog4.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.AllowDrop = true;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(72, 328);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 20;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // timer1
            // 
            this.timer1.Interval = 5;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // labelTotal1
            // 
            this.labelTotal1.AutoSize = true;
            this.labelTotal1.Location = new System.Drawing.Point(1110, 328);
            this.labelTotal1.Name = "labelTotal1";
            this.labelTotal1.Size = new System.Drawing.Size(37, 13);
            this.labelTotal1.TabIndex = 21;
            this.labelTotal1.Text = "Total1";
            // 
            // labelTotal2
            // 
            this.labelTotal2.AutoSize = true;
            this.labelTotal2.Location = new System.Drawing.Point(1110, 358);
            this.labelTotal2.Name = "labelTotal2";
            this.labelTotal2.Size = new System.Drawing.Size(37, 13);
            this.labelTotal2.TabIndex = 22;
            this.labelTotal2.Text = "Total2";
            // 
            // labelTotal3
            // 
            this.labelTotal3.AutoSize = true;
            this.labelTotal3.Location = new System.Drawing.Point(1110, 389);
            this.labelTotal3.Name = "labelTotal3";
            this.labelTotal3.Size = new System.Drawing.Size(37, 13);
            this.labelTotal3.TabIndex = 23;
            this.labelTotal3.Text = "Total3";
            // 
            // ButtonBet5
            // 
            this.ButtonBet5.Location = new System.Drawing.Point(16, 361);
            this.ButtonBet5.Name = "ButtonBet5";
            this.ButtonBet5.Size = new System.Drawing.Size(75, 23);
            this.ButtonBet5.TabIndex = 24;
            this.ButtonBet5.Text = "+ 5";
            this.ButtonBet5.UseVisualStyleBackColor = true;
            this.ButtonBet5.Click += new System.EventHandler(this.ButtonBet5_Click);
            // 
            // ButtonBet10
            // 
            this.ButtonBet10.Location = new System.Drawing.Point(97, 361);
            this.ButtonBet10.Name = "ButtonBet10";
            this.ButtonBet10.Size = new System.Drawing.Size(75, 23);
            this.ButtonBet10.TabIndex = 25;
            this.ButtonBet10.Text = "+ 10";
            this.ButtonBet10.UseVisualStyleBackColor = true;
            this.ButtonBet10.Click += new System.EventHandler(this.ButtonBet10_Click);
            // 
            // ButtonBet50
            // 
            this.ButtonBet50.Location = new System.Drawing.Point(178, 361);
            this.ButtonBet50.Name = "ButtonBet50";
            this.ButtonBet50.Size = new System.Drawing.Size(75, 23);
            this.ButtonBet50.TabIndex = 26;
            this.ButtonBet50.Text = "+ 50";
            this.ButtonBet50.UseVisualStyleBackColor = true;
            this.ButtonBet50.Click += new System.EventHandler(this.ButtonBet50_Click);
            // 
            // radioButtonDog1
            // 
            this.radioButtonDog1.AutoSize = true;
            this.radioButtonDog1.Location = new System.Drawing.Point(59, 399);
            this.radioButtonDog1.Name = "radioButtonDog1";
            this.radioButtonDog1.Size = new System.Drawing.Size(51, 17);
            this.radioButtonDog1.TabIndex = 27;
            this.radioButtonDog1.TabStop = true;
            this.radioButtonDog1.Text = "Dog1";
            this.radioButtonDog1.UseVisualStyleBackColor = true;
            this.radioButtonDog1.CheckedChanged += new System.EventHandler(this.radioButtonDog1_CheckedChanged);
            // 
            // radioButtonDog3
            // 
            this.radioButtonDog3.AutoSize = true;
            this.radioButtonDog3.Location = new System.Drawing.Point(59, 422);
            this.radioButtonDog3.Name = "radioButtonDog3";
            this.radioButtonDog3.Size = new System.Drawing.Size(51, 17);
            this.radioButtonDog3.TabIndex = 28;
            this.radioButtonDog3.TabStop = true;
            this.radioButtonDog3.Text = "Dog3";
            this.radioButtonDog3.UseVisualStyleBackColor = true;
            this.radioButtonDog3.CheckedChanged += new System.EventHandler(this.radioButtonDog3_CheckedChanged);
            // 
            // radioButtonDog2
            // 
            this.radioButtonDog2.AutoSize = true;
            this.radioButtonDog2.Location = new System.Drawing.Point(165, 399);
            this.radioButtonDog2.Name = "radioButtonDog2";
            this.radioButtonDog2.Size = new System.Drawing.Size(51, 17);
            this.radioButtonDog2.TabIndex = 29;
            this.radioButtonDog2.TabStop = true;
            this.radioButtonDog2.Text = "Dog2";
            this.radioButtonDog2.UseVisualStyleBackColor = true;
            this.radioButtonDog2.CheckedChanged += new System.EventHandler(this.radioButtonDog2_CheckedChanged);
            // 
            // radioButtonDog4
            // 
            this.radioButtonDog4.AutoSize = true;
            this.radioButtonDog4.Location = new System.Drawing.Point(165, 422);
            this.radioButtonDog4.Name = "radioButtonDog4";
            this.radioButtonDog4.Size = new System.Drawing.Size(51, 17);
            this.radioButtonDog4.TabIndex = 30;
            this.radioButtonDog4.TabStop = true;
            this.radioButtonDog4.Text = "Dog4";
            this.radioButtonDog4.UseVisualStyleBackColor = true;
            this.radioButtonDog4.CheckedChanged += new System.EventHandler(this.radioButtonDog4_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1179, 302);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 31;
            this.label2.Text = "Bettor\'s Balance";
            // 
            // bettorsCurrentBet1
            // 
            this.bettorsCurrentBet1.AutoSize = true;
            this.bettorsCurrentBet1.Location = new System.Drawing.Point(334, 331);
            this.bettorsCurrentBet1.Name = "bettorsCurrentBet1";
            this.bettorsCurrentBet1.Size = new System.Drawing.Size(35, 13);
            this.bettorsCurrentBet1.TabIndex = 32;
            this.bettorsCurrentBet1.Text = "label4";
            // 
            // bettorsCurrentBet2
            // 
            this.bettorsCurrentBet2.AutoSize = true;
            this.bettorsCurrentBet2.Location = new System.Drawing.Point(334, 361);
            this.bettorsCurrentBet2.Name = "bettorsCurrentBet2";
            this.bettorsCurrentBet2.Size = new System.Drawing.Size(35, 13);
            this.bettorsCurrentBet2.TabIndex = 33;
            this.bettorsCurrentBet2.Text = "label5";
            // 
            // bettorsCurrentBet3
            // 
            this.bettorsCurrentBet3.AutoSize = true;
            this.bettorsCurrentBet3.Location = new System.Drawing.Point(334, 386);
            this.bettorsCurrentBet3.Name = "bettorsCurrentBet3";
            this.bettorsCurrentBet3.Size = new System.Drawing.Size(35, 13);
            this.bettorsCurrentBet3.TabIndex = 34;
            this.bettorsCurrentBet3.Text = "label6";
            // 
            // placeBetsButton
            // 
            this.placeBetsButton.Location = new System.Drawing.Point(97, 452);
            this.placeBetsButton.Name = "placeBetsButton";
            this.placeBetsButton.Size = new System.Drawing.Size(75, 23);
            this.placeBetsButton.TabIndex = 35;
            this.placeBetsButton.Text = "Place Bet";
            this.placeBetsButton.UseVisualStyleBackColor = true;
            this.placeBetsButton.Click += new System.EventHandler(this.placeBetsButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1316, 487);
            this.Controls.Add(this.placeBetsButton);
            this.Controls.Add(this.bettorsCurrentBet3);
            this.Controls.Add(this.bettorsCurrentBet2);
            this.Controls.Add(this.bettorsCurrentBet1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.radioButtonDog4);
            this.Controls.Add(this.radioButtonDog2);
            this.Controls.Add(this.radioButtonDog3);
            this.Controls.Add(this.radioButtonDog1);
            this.Controls.Add(this.ButtonBet50);
            this.Controls.Add(this.ButtonBet10);
            this.Controls.Add(this.ButtonBet5);
            this.Controls.Add(this.labelTotal3);
            this.Controls.Add(this.labelTotal2);
            this.Controls.Add(this.labelTotal1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Dog4);
            this.Controls.Add(this.Dog3);
            this.Controls.Add(this.Dog2);
            this.Controls.Add(this.Dog1);
            this.Controls.Add(this.StartButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.minimumBetLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.raceTrackPictureBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.raceTrackPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dog1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dog2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dog3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dog4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox raceTrackPictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label minimumBetLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button StartButton;
        private System.Windows.Forms.PictureBox Dog1;
        private System.Windows.Forms.PictureBox Dog2;
        private System.Windows.Forms.PictureBox Dog3;
        private System.Windows.Forms.PictureBox Dog4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labelTotal1;
        private System.Windows.Forms.Label labelTotal2;
        private System.Windows.Forms.Label labelTotal3;
        private System.Windows.Forms.Button ButtonBet5;
        private System.Windows.Forms.Button ButtonBet10;
        private System.Windows.Forms.Button ButtonBet50;
        private System.Windows.Forms.RadioButton radioButtonDog1;
        private System.Windows.Forms.RadioButton radioButtonDog3;
        private System.Windows.Forms.RadioButton radioButtonDog2;
        private System.Windows.Forms.RadioButton radioButtonDog4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label bettorsCurrentBet1;
        private System.Windows.Forms.Label bettorsCurrentBet2;
        private System.Windows.Forms.Label bettorsCurrentBet3;
        private System.Windows.Forms.Button placeBetsButton;
    }
}

