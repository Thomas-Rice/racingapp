﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public class Guy
    {

        public string Name;
        public Bet MyBet;
        public int Cash;
        public int tempBetAmount = 0;

        public Label MyLabelTotal;
        public Label MyLabel;


        public void UpdateLabels()
        {
            MyLabel.Text = MyBet.GetDescription();
            MyLabelTotal.Text = Name + " has " + Cash + "Bucks";
        }

        public void ClearBet()
        {
            MyBet.Amount = 0;
        }

        public void changeBetAmount(int BetAmount)
        {
            tempBetAmount += BetAmount;
            MyLabel.Text = MyBet.changeLabelAmount(tempBetAmount);
        }

        public void changeDog(int dog)
        {
            MyLabel.Text = MyBet.changeLabelDog(dog);
        }


        public bool PlaceBet(int DogToWin)
        {
            MyBet.Amount = tempBetAmount;
            MyBet.Dog = DogToWin;

            if(tempBetAmount <= Cash)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public void Collect(int Winner)
        {
            Cash += MyBet.PayOut(Winner);
            ClearBet();
            UpdateLabels();

        }


    }


}
