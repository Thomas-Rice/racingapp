﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public class GreyHound
    {
        public int startingPosition = 45;
        public int raceTrackLength;
        public PictureBox myPictureBox = null;
        public int location = 0;
        public Random Randomizer;



        public bool Run()
        {
            location += Randomizer.Next(4);
            myPictureBox.Left = startingPosition + location;

            if(myPictureBox.Left >= 1200)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public void TakeStartingPositions()
        {
            location = 0;
            myPictureBox.Left = 45;
        }


    }
}
